<template>
  <div style="text-align:center;">
    <write-form type="modify" />
  </div>
</template>

<script>
import WriteForm from "@/components/board/include/WriteForm.vue";

export default {
  name: "boardmodify",
  components: {
    WriteForm,
  },
};
</script>
